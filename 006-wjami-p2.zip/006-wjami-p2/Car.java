/**
 * Class for the Car structure. 
 */
class Car {

	/**
	 * data attribute for the Car holding it's name.
	 */
	private String name;

	/**
	 * data attribute for the Car for holding the next car.
	 */
	private Car next;

	/**
	 * data attribute for the Car for holding the previous car.
	 */
	private Car previous;

	/**
	 * Constructor.
	 * @param  name parameter for initialization
	 */
	public Car(String name) {
		this.name = name;
		this.next = null;
		this.previous = null;
	}
	
	/**
	 * returns the next car.
	 * @return next car in the linked
	 */
	public Car getNext() {
		//returns the next car after this one
		//O(1)
		// return null;
		return this.next;
	}
	
	/**
	 * returns the previous car.
	 * @return previous car in the linked.
	 */
	public Car getPrevious() {
		//returns the car before this one
		//O(1)
		return this.previous;
	}
	
	/**
	 * updates the next car in the object.
	 * @param next car that is at next.
	 */
	public void setNext(Car next) {
		//sets the car after this one to next (the parameter)
		//O(1)
		this.next = next;
	}
	
	/**
	 * updates the previous car in the object.
	 * @param previous car that is at previous.
	 */
	public void setPrevious(Car previous) {
		//sets the car before this one to previous (the parameter)
		//O(1)
		this.previous = previous;
	}
	
	/**
	 * returns the name of the car.
	 * @return name of the car
	 */
	public String getName() {
		//return's the car's name
		//O(1)
		return this.name;
	}
	
	/**
	 * returns true with two objects are equal.
	 * @param  o object to be compared.
	 * @return   true if equal otherwise false
	 */
	public boolean equals(Object o) {
		//two cars are equal if they have the same name
		//O(1)
		if (this == o)
			return true;

		if (o instanceof Car)
		{
			Car other = (Car) o;
			if (this.name.equals(other.getName()))
				return true;
		}

		return false;
	}
	
	/**
	 * returns the string representation of the object.
	 * @return String representation.
	 */
	public String toString() {
		//return's the car's name
		//O(1)
		// return null;
		return this.name;
	}
	
	//example test code... edit this as much as you want!
	public static void main(String[] args) {
		Car c1 = new Car("C1");
		Car c2 = new Car("C2");
		
		c1.setNext(c2);
		c2.setPrevious(c1);
		
		if(c1.getName().equals("C1")) {
			System.out.println("Yay 1");
		}
		
		if(c1.getNext().equals(c2) && c2.getPrevious().equals(c1)) {
			System.out.println("Yay 2");
		}
		
		Car c1b = new Car("C1");
		if(c1.equals(c1b)) {
			System.out.println("Yay 3");
		}
		
		c1.printAscii();
	}
	
	/*****************************************************************/
	/****************** DO NOT EDIT BELOW THIS LINE ******************/
	/*****************************************************************/
	
	/**
	 * prints the ascii representation of the car.
	 */
	public void printAscii() {
		/*
		From: http://www.ascii-art.de/ascii/t/train.txt
		 _________
		 |O O O O|
		-|_______|
		   o   o  
		*/
		
		Car current = this;
		while(current != null) {
			System.out.print(" _________");
			current = current.getNext();
		}
		System.out.println();
		
		current = this;
		while(current != null) {
			System.out.print(" | "+String.format("%-5s",current.getName())+" |");
			current = current.getNext();
		}
		System.out.println();
		
		current = this;
		while(current != null) {
			System.out.print("-|_______|");
			current = current.getNext();
		}
		System.out.println();
		
		current = this;
		while(current != null) {
			System.out.print("   o   o  ");
			current = current.getNext();
		}
		System.out.println();
	}
}