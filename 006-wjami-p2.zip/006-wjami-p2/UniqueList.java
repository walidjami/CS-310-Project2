import java.util.Iterator;

/**
 * Class for Unique List (implementing iterator).
 */
class UniqueList<T> implements Iterable<T> {

	/**
	 * Private class for the node of the list
	 */
	private class ListNode<T> {
		private T data;
		private ListNode next;

		public ListNode(T data)
		{
			this.data = data;
		}

		public T getData()
		{
			return data;
		}

		public void setData(T data)
		{
			this.data = data;
		}

		public ListNode getNext()
		{
			return next;
		}

		public void setNext(ListNode next)
		{
			this.next = next;
		}
	}

	int size = 0;
	ListNode<T> head = null;

	/**
	 * appending the value at the end of the list.
	 * @param  value value to be appended
	 * @return       true if appending otherwise false.
	 */
	public boolean append(T value) {
		//adds an item to the list at the end
		
		//returns false if the value can not be added
		//(i.e. the value already exists in the list)
		
		//O(n) worst case, where n = the number of items
		//because you need to check for duplicates!
		
		ListNode<T> temp = head;
		ListNode<T> previous = null;
		ListNode<T> newNode = new ListNode<T>(value);
		
		if (temp == null)
		{
			head = newNode;
			size++;
			return true;
		}

		while (temp != null)
		{
			if (temp.getData().equals(value))
				return false;

			previous = temp;
			temp = temp.getNext();
		}

		previous.setNext(newNode);
		size++;

		return true;
	}
	
	public boolean remove(T value) {
		//remove a value from the list
		
		//return false if the item could not be found
		//return true if you remove the item
		
		ListNode<T> temp = head;
		ListNode<T> previous = null;

		while (temp != null)
		{
			if (temp.getData().equals(value)) {
				if (previous == null)
					head = head.getNext();
				else
				{
					previous.setNext(temp.getNext());
				}
				size--;
				return true;
			}

			previous = temp;
			temp = temp.getNext();
		}
		return false;
	}
	
	@SuppressWarnings("unchecked")
	public T get(T value) {
		//return null if the item could not be found
		//return the item FROM THE LIST if it was found
		//(do not return the parameter, while the value
		//is "equal" they may not be the same in computer
		//memory... review the difference between
		//.equals() and == from CS211)
		
		//O(n) worst case, where n = the number of items
		
		ListNode<T> temp = head;

		while (temp != null)
		{
			if (temp.getData().equals(value))
				return temp.getData();

			temp = temp.getNext();
		}

		return null;
	}
	
	public boolean contains(T value) {
		//return true if the item can be found in the
		//list, reuse code from get() to implement this
		//method
		
		//O(n) worst case, where n = the number of items
		
		ListNode<T> temp = head;

		while (temp != null)
		{
			if (temp.getData().equals(value))
				return true;
			temp = temp.getNext();
		}
		return false;
	}
	
	public int size() {
		//return the number of items in the set
		//O(1)
		return size;
	}
	
	public UniqueList<T> clone() {
		//make a copy of the UniqueList such that this is true:
		//	if s1 is a simple set containing {1, 2, 3} and s2 is a clone of s1, then:
		//	s1 != s2 BUT there exist three objects in s1 and s2 which are ==
		//see main method tests for example
		//O(n)
		UniqueList<T> newList = new UniqueList<>();

		ListNode<T> temp = head;
		while (temp != null)
		{
			newList.append(temp.getData());
			temp = temp.getNext();
		}

		return newList;
	}
	
	private class UniqueListIterator implements Iterator {
		ListNode<T> tempFront = head;

		public boolean hasNext()
		{
			return tempFront != null;
		}

		public T next()
		{
			ListNode<T> curr = tempFront;
			tempFront = tempFront.getNext();
			return curr.getData();
		}

		public void remove() 
	    { 
	        throw new UnsupportedOperationException(); 
	    } 
	}

	public Iterator<T> iterator() {
		//return an iterator over the list, returning the first item
		//through the last item (in that order).
		
		//also, you only need to implement next() and
		//hasNext() for this iterator, previous(), add(), etc.
		//are all optional on this assignment (implement them
		//if you want to use them in your code).
		return new UniqueListIterator();
	}
	
	//example test code... edit this as much as you want!
	public static void main(String[] args) {
		UniqueList<String> names = new UniqueList<>();
		
		if(names.append("Fred") && names.append("Alex") && !names.append("Fred")) {
			System.out.println("Yay 0");
		}
		
		if(names.size() == 2 && names.contains("Fred") && names.get("Alex").equals("Alex")) {
			System.out.println("Yay 1");
		}
		
		if(names.remove("Alex") && names.size() == 1 && names.get("Alex") == null) {
			System.out.println("Yay 2");
		}
		
		boolean hasEverything = false;
		for(String name : names) {
			if(hasEverything) {
				hasEverything = false;
				break;
			}
			
			hasEverything = name.equals("Fred");
		}
		if(hasEverything) {
			System.out.println("Yay 3");
		}
		
		class Cat {
			String name;
			public Cat(String name) { this.name = name; }
			public boolean equals(Object o) {
				if(o instanceof Cat) {
					Cat c = (Cat)o;
					return c.name.equals(this.name);
				}
				return false;
			}
		}
		
		UniqueList<Cat> catSet1 = new UniqueList<>();
		catSet1.append(new Cat("Sammy"));
		catSet1.append(new Cat("Grouchy"));
		UniqueList<Cat> catSet2 = catSet1.clone();
		if(catSet1 != catSet2 && catSet1.size() == catSet2.size()) {
			int matched = 0;
			for(Cat c : catSet1) {
				if(catSet2.get(c) == c) matched++;
			}
			if(matched == 2) {
				System.out.println("Yay 4");
			}
		}
	}
}